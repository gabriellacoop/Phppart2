</body>
<link rel="stylesheet" href="./css/style.css">
    <footer class="centered-footer">
        &copy; 2023 Gaby Database Web
    </footer>
</html>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to This Page</title>
    <link rel="stylesheet" href="https://www.phptutorial.net/app/css/style.css">
</head>

<body>
    <header>
        <h1>Welcome to This Page</h1>
    </header>
    <nav>
    <div class="btn-group-vertical">
        <button onclick="location.href='login.php'">Subscribe</button>
        <button onclick="location.href='log.php'">Login</button>
        <button onclick="location.href='upload.php'">Upload Picture</button>
    </div>
    </nav>
